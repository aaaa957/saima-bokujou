#!/usr/bin/env node
'use strict';
// Six predeclared candidates; four calibration events each. No reserved-year
// outputs or retrospective dropping of failed jobs enter this small screen.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{execFileSync}=require('node:child_process');
const {Worker,isMainThread,parentPort,workerData}=require('node:worker_threads'),{HASH,BASE,q}=require('./system-reality-v9');
const {references,makeJobs,runJob,compare,METRICS}=require('./race-validation-v11');
const ROOT=path.resolve(__dirname,'..'),sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const NAMES=['current','fast80-peak08','fast80-peak12','air2-fast80-peak08','air4-fast80-peak12','air2-fast80-peak12-cost105'];
if(require.main===module&&!isMainThread){for(const job of workerData.jobs){try{parentPort.postMessage({row:runJob(job,workerData.source,workerData.generatorSource,workerData.parameters[job.gridVariant])});}
  catch(e){parentPort.postMessage({job,jobKey:sha(JSON.stringify(job)),error:String(e.stack)});}}}
else if(require.main===module){
  const args=process.argv.slice(2),arg=(key,value)=>{const i=args.indexOf(key);return i<0?value:args[i+1];};
  const sourcePath=path.resolve(ROOT,arg('--source','sim.js')),read=()=>{const b=fs.readFileSync(sourcePath);return (b[0]===0x1f&&b[1]===0x8b?require('node:zlib').gunzipSync(b):b).toString('utf8');},source=read();
  const expected=arg('--expected-source','1ca77ab4eacdd18ec98ed8bcc6b5e3cfa74525dd16dfca3f2fbe6d151304f818');assert.equal(HASH(source),expected,'Calibration source not the agreed frozen candidate');
  const generatorSource=execFileSync('git',['show',BASE+':sim.js'],{cwd:ROOT,encoding:'utf8',maxBuffer:2e6}),ref=references();
  const cases=makeJobs('calibration',ref.races,1,'fixed-v8').filter(j=>[1200,2400].includes(j.length));assert.equal(cases.length,4);
  const parameters=Object.fromEntries(NAMES.map(name=>[name,JSON.parse(fs.readFileSync(path.join(ROOT,'tests/fixtures/race-validation-v11-parameters',name+'.json'),'utf8'))]));
  const jobs=NAMES.flatMap(name=>cases.map(job=>({...job,gridVariant:name}))),declared=new Map(jobs.map(j=>[sha(JSON.stringify(j)),j])),covered=new Set();
  const workers=Number(arg('--workers','2'));assert(Number.isInteger(workers)&&workers>=1&&workers<=2);
  const output=path.resolve(ROOT,arg('--out','docs/calibration-screen-v11.json')),driver=fs.readFileSync(path.join(__dirname,'race-validation-v11.js'),'utf8'),orchestrator=fs.readFileSync(__filename,'utf8');
  fs.mkdirSync(path.dirname(output),{recursive:true});for(const [suffix,text] of [['source.js',source],['driver.js',driver],['orchestrator.js',orchestrator]])fs.writeFileSync(output+'.'+suffix+'.gz',require('node:zlib').gzipSync(text));
  const protocol={sourceNormalizedSha256:HASH(source),generatorCommit:BASE,generatorNormalizedSha256:HASH(generatorSource),driverNormalizedSha256:HASH(driver),orchestratorNormalizedSha256:HASH(orchestrator),workers,
    variants:NAMES,parameters,jobs,referenceHashes:ref.hashes,scope:'Four 2023/2024 official calibration events (1200/2400), one fixed-v8 seed each, six declared variants. Twenty-four runs, four real events; not independent real replication. No reserved2020 or internal-year selection.',
    selection:'Report all broad-speed gate failures and all 12 residuals. Compare event-wise paired changes. Pareto and normalized joint loss are a small-sample screen, not proof of reality fit or a reserved-year result.'};
  const report={protocol,protocolHash:HASH(JSON.stringify(protocol)),startedAt:new Date().toISOString(),samples:[],errors:[],arms:[],integrity:{complete:false},closed:false},start=Date.now();let ended=0;
  function save(){
    report.wallSeconds=(Date.now()-start)/1000;
    report.arms=NAMES.map(name=>{const rows=report.samples.filter(r=>r.gridVariant===name),comparisons=compare(rows,ref.races);return {name,completed:rows.length,comparisons,
      metrics:Object.fromEntries(METRICS.map(k=>[k,{medianError:q(comparisons.map(c=>c.metrics[k].error)),meanAbsoluteError:comparisons.length?comparisons.reduce((s,c)=>s+Math.abs(c.metrics[k].error),0)/comparisons.length:null}])),
      gateFailures:comparisons.flatMap(c=>Object.entries(c.gates).filter(([,pass])=>!pass).map(([gate])=>({id:c.id,gate}))),engineeringFailures:rows.filter(r=>!r.engineering.passed).map(r=>({id:r.id,failedChecks:r.engineering.failedChecks}))};});
    report.paired=NAMES.filter(n=>n!=='current').map(name=>({name,rows:cases.map(job=>{const base=report.samples.find(s=>s.gridVariant==='current'&&s.id===job.id),row=report.samples.find(s=>s.gridVariant===name&&s.id===job.id);
      return {id:job.id,length:job.length,complete:!!row&&!!base,...(row&&base?{sameInputField:row.inputHash===base.inputHash,differences:Object.fromEntries(METRICS.map(k=>[k,row[k]-base[k]])),absoluteResidualChange:Object.fromEntries(METRICS.map(k=>{const reality=ref.races.find(r=>r.id===job.id).metrics[k];return [k,Math.abs(row[k]-reality)-Math.abs(base[k]-reality)];}))}:{})};})}));
    report.integrity={complete:report.closed&&covered.size===jobs.length,covered:covered.size,total:jobs.length,passedEngineering:report.errors.length===0&&report.samples.every(r=>r.engineering.passed),
      failures:report.samples.filter(r=>!r.engineering.passed).map(r=>({variant:r.gridVariant,id:r.id,checks:r.engineering.failedChecks})),missingJobKeys:[...declared.keys()].filter(k=>!covered.has(k)),fullRaceExecutions:report.samples.length,partialExecutions:0,
      maxMotionError:Math.max(0,...report.samples.map(r=>r.maxMotionError)),maxWorkError:Math.max(0,...report.samples.map(r=>r.maxWorkError)),maxReserveError:Math.max(0,...report.samples.map(r=>r.maxReserveError)),maxUnpaid:Math.max(0,...report.samples.map(r=>r.maxUnpaid)),bodyOverlapRuns:report.samples.filter(r=>r.bodyOverlapFrames>0).length};
    const tmp=output+'.tmp';fs.writeFileSync(tmp,JSON.stringify(report)+'\n');fs.renameSync(tmp,output);
  }
  for(let i=0;i<workers;i++){
    const worker=new Worker(__filename,{workerData:{source,generatorSource,parameters,jobs:jobs.filter((_,j)=>j%workers===i)}});
    worker.on('message',m=>{const key=m.row?.jobKey??m.jobKey;if(!declared.has(key)||covered.has(key))report.errors.push({error:'Foreign/duplicate worker result',received:m});else{covered.add(key);if(m.error)report.errors.push(m);else report.samples.push(m.row);}save();
      console.log(JSON.stringify({done:covered.size,total:jobs.length,variant:m.row?.gridVariant??m.job?.gridVariant,id:m.row?.id??m.job?.id,wallSeconds:report.wallSeconds,engineering:m.row?.engineering,error:m.error??null}));});
    worker.on('error',e=>report.errors.push({worker:i,error:String(e.stack)}));worker.on('exit',code=>{if(code)report.errors.push({worker:i,error:'Worker exit '+code});if(++ended===workers){report.closed=true;report.sourceFileStillSameAtEnd=HASH(read())===HASH(source);save();console.log(JSON.stringify({output,source:HASH(source),wallSeconds:report.wallSeconds,integrity:report.integrity}));if(!report.integrity.complete||!report.integrity.passedEngineering)process.exitCode=1;}});
  }
}
